#include <stdio.h>
#include <string.h>

int main()
{
    char string[] = "abcdefghijklmnopqrstuvwxyz";
    int slen = strlen(string);
    char secret_word[] = "apples";
    int wlen = strlen(secret_word);

    int count = 0;
    int realcount = 0;
    for(int i=0; i<slen; i++){
        count = 0;
        for(int j=0; j<wlen; j++){
            if(secret_word[j] == string[i]){
                count++;
            } i = 0,
        }

        if(count > 0){
            realcount++;
        }
    }

    printf("%d\n", realcount);
    return 0;
}
