#include <stdio.h>


int resultf(char secret_word[], char guessed)
{

    int sum = 0;
    int result =0;
    for(int i=0; i<5; i++)
       {
        if(secret_word[i] == guessed){
            sum++;
        }
    }

    if(sum > 0){
        return 1;
    }else{
        return 0;
    }
}

int main()
{
    char secret_word[] = "apple";
    char guessed;
    printf("Guess the character:");
    scanf("%c", &guessed);

    printf("%d\n", resultf(secret_word, guessed));

    return 0;
}
