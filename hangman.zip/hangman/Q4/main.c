#include <stdio.h>
#include <string.h>

int main()
{
    char available[] = "abcdefghijklmnopqrstuvwxyz";
    char guessed[] = "eikprs";

    int availablelen = strlen(available);
    int guessedlen   = strlen(guessed);

    for(int i=0; i<availablelen; i++){
        for(int j=0; j<guessedlen; j++){
            if(available[i] == guessed[j]){
                available[i] = 1;
            }
        }
    }

    int sum=0;
    for(int i=0; i<availablelen; i++){
        if(available[i] == 1){
           sum++;
        }
    }

    int nlen = availablelen - sum;
    char new[nlen];
    int j = 0;
    for(int i=0; i<availablelen; i++){
        if(available[i] != 1){
            new[j] = available[i];
            j++;
        }

    }

    for(int i=0; i<nlen; i++){
        printf("%c\t", new[i]);
    }

    printf("\n");
    return 0;
}
