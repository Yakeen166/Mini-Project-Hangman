#include <stdio.h>
#define size 5

int main()
{
    char secret_word[] = "apple";
    char guessed[1];

    printf("Guess the character:");
    scanf("%c", &guessed);
    int sum = 0;

    for(int i=0; i<5; i++){
        if(secret_word[i] == guessed[0]){
            sum++;
        }
    }

    if(sum > 0){
        printf("1\n");
    }else{
        printf("0\n");
    }

    return 0;

}
