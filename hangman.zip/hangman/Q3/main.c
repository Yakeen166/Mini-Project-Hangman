#include <stdio.h>
#define size 5

int main()
{
    char secret_word[size] = "apple";
    char guessed[size] = {'e', 'i', 'k', 'p', 'r'};
    char new[size];
    char underscore = '_';
    for(int i=0; i<size; i++){
        for(int j=0; j<size; j++){
            if(secret_word[i] == guessed[j]){
                new[i] = secret_word[i];
                break;
            }else{
                new[i] = underscore;
             }
        }
    }

    for(int i=0; i<size; i++){
        printf("%c\t", new[i]);
    }
    printf("\n");
    printf("\n");
    return 0;
}
