#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

int num(){
    int j = 4;
    int k = 0;
    srand((unsigned)time(NULL));
    k = rand() % j;
    return k;
}
int main()
{
    char list[4][20] = {"apple", "dog", "cat", "orange"};
    printf("%s\n", list[num()]);
    return 0;
}
